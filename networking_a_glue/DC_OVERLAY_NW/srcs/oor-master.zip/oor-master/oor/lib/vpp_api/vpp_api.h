/*
 * vpp_api.h
 *
 *  Created on: Feb 22, 2017
 *      Author: alopez
 */

#ifndef OOR_LIB_VPP_API_VPP_API_H_
#define OOR_LIB_VPP_API_VPP_API_H_

int vpp_is_enabled();
int vpp_init_api();
int vpp_uninit_api();

#endif /* OOR_LIB_VPP_API_VPP_API_H_ */

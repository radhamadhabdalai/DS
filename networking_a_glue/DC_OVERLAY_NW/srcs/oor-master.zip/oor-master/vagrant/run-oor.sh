#!/bin/bash

/usr/local/sbin/oor -D -f /etc/oor.conf

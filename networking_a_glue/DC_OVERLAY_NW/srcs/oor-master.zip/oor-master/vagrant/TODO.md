# TODO

* Create two xTR VMs with one EID-only VM behind each
* Maybe make it possible to connect the testbed to the LISP Beta Network
* Maybe use the testbed for automated testing
* Explore, automate, and document the usage of NETCONF between OOR and ODL

#!/bin/bash

cp /vagrant/vagrant/oor.$1.conf /etc/oor.conf

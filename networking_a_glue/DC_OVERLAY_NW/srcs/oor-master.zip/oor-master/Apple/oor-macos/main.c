//
//  main.c
//  oor-macos
//
//  Created by Oriol Marí Marqués on 30/06/2017.
//
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    oor_start();
    return 0;
}

#define BUFLEN             512
#define NPACK               1000000
#define SPORT               50000
#define SADDR               "127.0.0.1" /* Server address */

/* Max pending connection requests (TCP only)*/
#define QUEUELENGTH         2

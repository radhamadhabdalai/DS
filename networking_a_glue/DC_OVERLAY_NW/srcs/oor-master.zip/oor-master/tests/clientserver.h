#define BUFLEN             512
#define NPACK               1000000

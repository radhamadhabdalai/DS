#ifndef __LIB_ABYSS_HPP__
#define __LIB_ABYSS_HPP__
#include <abyss/server.hpp>
#include <abyss/client.hpp>

namespace abyss
{
  struct Globals
  {
    Globals()
    {
    }
    ~Globals()
    {
    }
  };
}  // namespace abyss

#endif

# libabyss

![abyss.jpeg](abyss.jpeg)

http client/server with multiple layers of the abysmal hellscape of the bottomless pit of standards by the w3c encapsulated in a neat standalone little library.

Try not to die.


var lokinet = require("bindings")("lokinet");
console.log(lokinet);
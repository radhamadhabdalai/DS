#!/bin/sh
killall -9 lokinet1
killall -9 lokinet2
killall -9 lokinet3
killall -9 lokinet4
killall -9 lokinet5
killall -9 lokinet6

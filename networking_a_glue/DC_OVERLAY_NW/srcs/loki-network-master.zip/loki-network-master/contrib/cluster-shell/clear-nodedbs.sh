#!/bin/sh
rm -fr loki*/tmp-nodes
rm  loki*/profile.dat

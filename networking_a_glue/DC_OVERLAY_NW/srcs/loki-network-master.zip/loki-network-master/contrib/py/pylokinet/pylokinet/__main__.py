#!/usr/bin/env python3

from pylokinet.instance import main 
main()
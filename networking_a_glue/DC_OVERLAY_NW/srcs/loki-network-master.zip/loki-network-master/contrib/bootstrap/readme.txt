usage:

./make-bootstrap-list.sh $(find $HOME/.lokinet/netdb | grep \\.signed$) > bootstrap.signed

package network.loki.lokinet;


import android.net.VpnService;

public class LokinetService extends VpnService
{
    
}

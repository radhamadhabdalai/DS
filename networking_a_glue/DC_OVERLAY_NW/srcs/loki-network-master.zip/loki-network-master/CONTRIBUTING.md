[Español](CONTRIBUTING_es.md)
# Do

* Act like a responsible adult.

* RUN `make format` BEFORE COMMITING ALWAYS.

# Do NOT

* Bring off topic or non technical issues to the issue tracker.

* Pester contributors.

# We WILL

* Merge Spelling mistake corrections (I have lots of those because spelling is HARD)

* Merge code based on its correctness, Including patches via email from (pseudo/fully) anonymous contributors.

# We WILL NOT

* Accept patches with tabs

* Merge large and pointless or pedantic changes, (i.e. code formatting shift)

## additional notes

github's ui doesn't seem accept this file as a real code of conduct.

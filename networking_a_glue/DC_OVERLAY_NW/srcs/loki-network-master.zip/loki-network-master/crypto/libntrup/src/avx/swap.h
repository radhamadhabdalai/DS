#ifndef swap_h
#define swap_h

#define swap crypto_kem_sntrup4591761_avx_swap
extern void
swap(void *, void *, int, int);

#endif

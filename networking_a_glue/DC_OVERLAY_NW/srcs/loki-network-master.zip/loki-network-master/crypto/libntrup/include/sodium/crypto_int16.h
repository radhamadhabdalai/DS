#include <stdint.h>
typedef int16_t crypto_int16;
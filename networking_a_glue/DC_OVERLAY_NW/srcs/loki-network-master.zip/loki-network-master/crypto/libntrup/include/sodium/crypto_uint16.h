#include <stdint.h>
typedef uint16_t crypto_uint16;
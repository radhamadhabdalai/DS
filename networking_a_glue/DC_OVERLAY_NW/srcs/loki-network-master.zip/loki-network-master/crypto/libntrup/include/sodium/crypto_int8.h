#include <stdint.h>
typedef int8_t crypto_int8;
#pragma once
#include <stdint.h>
typedef int32_t crypto_int32;

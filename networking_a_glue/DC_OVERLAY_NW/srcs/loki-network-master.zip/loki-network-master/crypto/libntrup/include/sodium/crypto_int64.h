#include <stdint.h>
typedef int64_t crypto_int64;
#ifndef LLARP_COMMON_HPP
#define LLARP_COMMON_HPP
#ifdef __STRICT_ANSI__
#define INLINE __inline__
#else
#define INLINE inline
#endif

#include <cstdint>
#include <cstdlib>
#endif

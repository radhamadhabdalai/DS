#include <router/i_outbound_message_handler.hpp>

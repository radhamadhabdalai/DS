#include <dns/string.hpp>

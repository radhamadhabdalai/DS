#ifndef LLARP_DNS_QUERY_HPP
#define LLARP_DNS_QUERY_HPP

#endif

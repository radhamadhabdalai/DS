#include <dns/query.hpp>

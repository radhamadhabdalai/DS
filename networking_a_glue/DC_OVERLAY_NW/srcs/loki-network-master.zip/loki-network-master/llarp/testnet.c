#ifdef LOKINET_SHADOW
#include <llarp.h>

/** insert shadow test network specific code here */

#endif

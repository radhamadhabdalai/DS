#include <crypto/crypto.hpp>

namespace llarp
{
  Crypto* CryptoManager::m_crypto = nullptr;
}

#ifndef LOCALNODE_H
#define LOCALNODE_H

#include "Common.h"

void	 InitLocalNode();

uint	 GetUpTime();
uchar	*GetNodeId();
uint	 GetListeningPort();

#endif /*LOCALNODE_H*/
#include "Common.h"

namespace Epyks
{
	class SkypeSession
	{
	private:
		string UserName;
		string Password;

	};
};
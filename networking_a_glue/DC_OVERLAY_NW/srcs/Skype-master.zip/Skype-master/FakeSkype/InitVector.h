#ifndef INITVECTOR_H
#define INITVECTOR_H

#include "Common.h"

unsigned int Update(unsigned int iv);
unsigned int GenIV();

#endif /*INITVECTOR_H*/
#ifndef LOGIN_H
#define LOGIN_H

#include "Common.h"

void	PerformLogin(char *User, char *Pass);

#endif /*LOGIN_H*/
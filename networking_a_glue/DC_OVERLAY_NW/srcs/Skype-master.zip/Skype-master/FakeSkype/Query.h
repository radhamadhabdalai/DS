#ifndef QUERY_H
#define QUERY_H

#include "Common.h"

void	HandleQuery(Host Session_SN, uchar *Query, int Size);

#endif /*QUERY_H*/
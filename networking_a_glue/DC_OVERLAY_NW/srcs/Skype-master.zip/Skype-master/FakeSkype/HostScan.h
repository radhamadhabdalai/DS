#ifndef HOSTSCAN_H
#define HOSTSCAN_H

#include "Common.h"

void	HostScan(Host *Session_SN);

#endif /*HOSTSCAN_H*/
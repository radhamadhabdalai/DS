#ifndef EVENTS_H
#define EVENTS_H

#include "Common.h"

void	EventContacts(char *User, char *Pass);

#endif /*EVENTS_H*/
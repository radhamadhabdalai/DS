Skype
=====

For context, visit : http://www.oklabs.net/skype-reverse-engineering-genesis/

Source information : http://www.oklabs.net/fakeskype-source-code/

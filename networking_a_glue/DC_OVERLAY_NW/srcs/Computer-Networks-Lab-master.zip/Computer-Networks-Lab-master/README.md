# Computer-Networks-Lab

* File transfers using pipes, sockets
* Communication using TCP, UDP
* File transfer through tunnels(VPN)
* Instant chatting protocol with GUI
* Audio file transfer with congestion control
* File transfers using overlay routers

for i in *.c
do 
	${i%.c}   
done
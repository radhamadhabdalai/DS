for i in *.c
do 
	rm ${i%.c}   
	rm $i
done